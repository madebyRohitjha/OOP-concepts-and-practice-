
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
using namespace std;

// User class
class User {
public:
    string username;
    string password;

    // Constructor
    User(string u, string p) {
        username = u;
        password = p;
    }

    // Convert user information into a file line
    string toLine() const {
        return username + "," + password;
    }

    // Create a User from a file line
    static User fromLine(string line) {
        stringstream ss(line);
        string u, p;

        getline(ss, u, ',');
        getline(ss, p);

        return User(u, p);
    }
};

// AuthSystem class
class AuthSystem {
private:
    string filename;

public:
    // Constructor
    AuthSystem(string fname) {
        filename = fname;
    }

    // Signup: Save user to file
    void signup(const User& user) {
        ofstream file(filename, ios::app);

        if (file.is_open()) {
            file << user.toLine() << endl;
            file.close();

            cout << "Signup successful!" << endl;
        } else {
            cout << "Error opening file!" << endl;
        }
    }

    // Login: Check username and password
    bool login(string name, string pass) {
        ifstream file(filename);
        string line;

        while (getline(file, line)) {
            User user = User::fromLine(line);

            if (user.username == name &&
                user.password == pass) {
                file.close();
                return true;
            }
        }

        file.close();
        return false;
    }
};

// Main function
int main() {
    AuthSystem auth("users.txt");

    int choice;
    string username, password;

    do {
        cout << "\n===== AUTHENTICATION SYSTEM =====" << endl;
        cout << "1. Signup" << endl;
        cout << "2. Login" << endl;
        cout << "3. Quit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1: {
                cout << "Enter username: ";
                cin >> username;

                cout << "Enter password: ";
                cin >> password;

                User newUser(username, password);
                auth.signup(newUser);

                break;
            }

            case 2: {
                cout << "Enter username: ";
                cin >> username;

                cout << "Enter password: ";
                cin >> password;

                if (auth.login(username, password)) {
                    cout << "Welcome, " << username << endl;
                } else {
                    cout << "Login failed." << endl;
                }

                break;
            }

            case 3:
                cout << "Goodbye!" << endl;
                break;

            default:
                cout << "Invalid choice. Try again." << endl;
        }

    } while (choice != 3);

    return 0;
}
